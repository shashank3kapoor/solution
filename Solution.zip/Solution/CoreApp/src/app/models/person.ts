export class Person {
    firstName: string;
    lastName: string;
}